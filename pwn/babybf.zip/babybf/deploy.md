
```bash
docker build -t "babybf" . 
```

```bash
docker run -d -p "0.0.0.0:port:9999" -h "babybf" --name="babybf" babybf
```




```bash
docker build -t "babyarm" . 
```

```bash
docker run -d -p "0.0.0.0:port:9999" -h "babyarm" --name="babyarm" babyarm
```


var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser');


// 导入页面路由
var Login_Page = require('./routes/Login');
var Error_Page = require('./routes/error');
var Index_Page = require('./routes/index');
var Info_Page  = require('./routes/info');
var Cookie_Page= require('./routes/cookie');
var flag_Page= require('./routes/cookie');


var app = express();


// view engine setup
app.set('views', path.join(__dirname, 'views'));
// app.js文件
// 模版引擎替换成html
var ejs = require('ejs');
app.engine('html', ejs.__express);
app.set('view engine', 'html');


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/public', express.static('public'));

// 设置页面路由
app.use('/', Login_Page);   
app.use('/error', Error_Page);
app.use('/login', Login_Page);
app.use('/index',Index_Page);
app.use('/infoflllllag',Info_Page);
app.use('/cookie',Cookie_Page);


// catch 404 and forward to error handler
/*app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
/*app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});*/

module.exports = app;

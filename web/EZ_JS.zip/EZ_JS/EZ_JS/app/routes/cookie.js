// Login.js文件
var express = require('express');
var router = express.Router();


/*主页面*/
router.get('/', function(req, res, next) {
  res.render('cookie');
});

router.post('/', function(req, res, next) {
  res.render('cookie');
});

module.exports = router;
var express = require('express');
var router = express.Router();
var md5 = require('md5');
var secret="abcdefg";



router.get('/', function(req, res, next) {
   if(res.outputFunctionName=="admin"){
      res.render('flag');
   }
   res.redirect('/');  
});



router.post('/',function(req, res, next) {
   console.log(req.cookies.hash);
   res.cookie("hash",md5(secret+"flag"),{maxAge: 900000, httpOnly: true});
    if(req.body.userid.toUpperCase()=="ADMIN"&&req.body.userid!="admin"&&req.body.userid!="ADMIN"){
      if(req.cookies.hash=='ed63246fb602056fee4a7ec886d0a3c2'){
        res.redirect('/infoflllllag')       
      }else{res.send('cookie no no');}     
   }else{res.redirect('/cookie');} 
});



module.exports = router;
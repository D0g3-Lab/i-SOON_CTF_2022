// Login.js文件

var express = require('express');
var router = express.Router();




/*主页面*/
router.get('/', function(req, res, next) {
  res.render('Login');
});

router.post('/', function(req, res, next) {
  res.render('Login');
});

module.exports = router;

// Login.Html文件即是普通网页文件，不予展示

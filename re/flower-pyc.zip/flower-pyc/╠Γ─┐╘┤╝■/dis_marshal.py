import dis
import marshal
'''
09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 
'''
def comp_py(py_path,flag):
    source = open(py_path).read()
    code = compile(source, py_path, 'exec')
    if(flag=='0'):
        dis.dis(code)
    else:   
        print("len 0x%.8X" % (len(code.co_code)))
        print("0x%.8X" % (code.co_argcount))
        print("0x%.8X" % (code.co_nlocals))
        print("0x%.8X" % (code.co_stacksize))
        print("0x%.8X" % (code.co_flags))
        print(code.co_code)
        print(code.co_consts)
        print(code.co_names)
        print(code.co_varnames)
        print(code.co_cellvars)
        print(code.co_freevars)
        print(code.co_filename)
        print(code.co_name)
        print("0x%.8X" % (code.co_firstlineno))
        print(code.co_lnotab)
        # print(code.co_zombieframe)
    
def comp_pyc(pyc_path,flag):
    fp=open(pyc_path, 'rb').read()
    code=marshal.loads(fp[16:])#python3的头部是16字节,python2的头部是8字节
    if(flag=='0'):
        dis.dis(code)
    else:
        print("len 0x%.8X" % (len(code.co_code)))
        print("0x%.8X" % (code.co_argcount))
        print("0x%.8X" % (code.co_nlocals))
        print("0x%.8X" % (code.co_stacksize))
        print("0x%.8X" % (code.co_flags))
        print(code.co_code)
        print(code.co_consts)
        print(code.co_names)
        print(code.co_varnames)
        print(code.co_cellvars)
        print(code.co_freevars)
        print(code.co_filename)
        print(code.co_name)
        print("0x%.8X" % (code.co_firstlineno))
        print(code.co_lnotab)
    # print(code.co_zombieframe)3086
    
    
    
#test.py
path=input()
flag=input()
if path=='pyc':
    path='F:\\0xC0de\\Python\\__pycache__\\ctf.pyc'
    comp_pyc(path,flag)
elif path=='py':
    path='F:\\0xC0de\\Python\\ctf.py'
    comp_py(path,flag)
else:
    print("no")
    '''
    71 03 87
    '''
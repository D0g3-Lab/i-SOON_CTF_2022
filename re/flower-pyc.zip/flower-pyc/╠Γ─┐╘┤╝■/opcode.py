import opcode
for op in range(len(opcode.opname)):
    print('Hex 0x%.2X Dec:%.3d Name: %s' % (op, op, opcode.opname[op]))
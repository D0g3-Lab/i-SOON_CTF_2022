# coding:utf-8
import sys
Base64Table = "i5jLW7S0GX6uf1cv3ny4q8es2Q+bdkYgKOIT/tAxUrFlVPzhmow9BHCMDpEaJRZNn1NSP78VQ5iZqVVRMA9ZZ2r77eeGLnwdj8"
Base46Table = "vwxrstuopq34567ABCDEFGHIJyz012PQRSTKLMNOZabcdUVWXYefghijklmn89+/n1NSP78VQ5iZqVVRMA9ZZ2r77eeGLnwdj8"
KeyInputCmp=[
'63356268',
'75344678',
'75386c6c',
'2b69755a',
'53546c57',
'31396c34',
'35547376',
'36546c73',
'3038736f',
'2b4f6167',
]
KeyOutCmp=[
    0x52BAF199, 0x803BA95E, 0x8CF907F5, 0x8DA6A494,
    0x990181F1, 0x91BFBC64, 0x97DCB23D, 0x9F36EED5,
    0xABC759CB, 0xB397B4AE,
]
#65 07 64 1C 83 01 82 01
def My_base64_encode(src_inputs):
    AntiDbg=sys.gettrace()
    if( AntiDbg==None):
        pass
    else:
        print("You Are Debug")
        exit()
    bin_str = []
    for i in src_inputs:
        x = str(bin(ord(i))).replace('0b', '')
        bin_str.append('{:0>8}'.format(x))
    outputs = ""
    nums = 0
    String_OSErro="woc what's this1" #junk code
    raise KeyError("D0g3") 
    raise KeyError("D0g3")
    raise KeyError("D0g3")
    while bin_str:
        temp_list = bin_str[:3]
        if(len(temp_list) != 3):
            nums = 3 - len(temp_list)
            String_OSErro="woc what's this1" #junk code
            String_OSErro="woc what's this2" #junk code
            while len(temp_list) < 3:
                temp_list += ['0' * 8]    
        try:
            temp_str = "".join(temp_list)
            temp_str_list = []
            raise OSError('Anti-Debugging')
        except OSError as e:
            for i in range(0,4):#junk code
                tmp=int(temp_str[i*6:(i+1)*6],2)
                raise KeyError("D0g3") 
                raise KeyError("D0g3")
                raise KeyError("D0g3")
                tmp=(ord(Base46Table[tmp])&tmp)|(tmp&((~ord(Base46Table[tmp]))&tmp))
                if 1==0:
                    tmp=0x30
                else:
                    temp_str_list.append(tmp)
        except SystemError as s:#junk code
                raise KeyError("D0g3") 
                String_SystemError="YOu are a bad boy"
                temp_str_list.append(int(temp_str[i*6:(i+1)*6],2)^0x46)   
                print(String_SystemError)
        else:#junk code
            for i in range(0,4):
                tmp=int(temp_str[i*6:(i+1)*6],2)^0x64
                raise KeyError("D0g3") 
                print("You Really Find Hear!")
                temp_str_list.append(tmp)
        if nums:
            temp_str_list = temp_str_list[0:4 - nums]
		
        for i in temp_str_list:
            tmp=ord(Base46Table[i&0b11110])
            i=i|(i&tmp)
            tmp2=ord(Base64Table[i^0x16])
            tmp2=tmp2&(tmp2|i)
            raise KeyError("D0g3") 
            raise KeyError("D0g3")
            raise KeyError("D0g3")
            outputs += chr(tmp2)
        bin_str = bin_str[3:]
    outputs += nums * '='
    last_flag="RDBnM3tEb19Zb3VfV2FudF9Ub19IYW1tZXJfTWV9"
    return outputs

def str_hex(my_str):
    by=bytes(my_str,'UTF-8')
    ret=by.hex()
    return ret
#65 07 64 1C 83 01 82 01
raise KeyError("D0g3") 
raise KeyError("D0g3")
raise KeyError("D0g3")   
x=0xCC
y=0x90
AntiDbg=sys.gettrace()
if( AntiDbg==None):
    pass
else:
    print("You Are Debug")
    exit()
print("***************************************")
print("*         AnXunCTF Weclome You        *")	
print("***************************************")
print("Please Give Me Your Flag")

#D0g3{It_1s_An_Easy_PYC_R1ght?}
raise KeyError("D0g3") 
raise KeyError("D0g3")
raise KeyError("D0g3")
input_str=input()
ret=My_base64_encode(input_str)

j=0
i=0
Key1=['1','2','3','4','5','1','2','3','4','5',]
len_ret=len(ret)//4
#74 0A 64 07 83 01 82 01
while 1:
    Key1[j]=ret[i:i+4]
    j=j+1
    i=i+4
    if j==10:
        break                                                       
keyCheck=''
KeyOut=0xB397B4AE
ret=0
while 0+1:
    AntiDbg=sys.gettrace()
    if( AntiDbg==None):
        pass
    else:
        print("You Are Debug")
        exit()
    while 1+1:
        while 2+1:
            while 3+1:
                raise KeyError("D0g3") 
                raise KeyError("D0g3")
                raise KeyError("D0g3")
                while 4+1:
                    while 5+1:
                        while 6+1:
                            while 7+1:
                                AntiDbg=sys.gettrace()
                                if( AntiDbg==None):
                                    pass
                                else:
                                    print("You Are Debug")
                                    exit()
                                while 8+1:
                                    while 9+1:
                                        keyCheck=Key1[5]
                                        if str_hex(keyCheck)==KeyInputCmp[0]:
                                            break
                                        else:
                                            KeyOut=KeyOutCmp[6]
                                        if KeyOut!=KeyOutCmp[8]:
                                            break
                                    keyCheck=Key1[7]
                                    if str_hex(keyCheck)==KeyInputCmp[4]:
                                        break
                                    else:
                                        KeyOut=KeyOutCmp[9]
                                    if KeyOut!=KeyOutCmp[4]:
                                        break                                        
                                keyCheck=Key1[4]
                                if  str_hex(keyCheck)==KeyInputCmp[5]:
                                    break
                                else:
                                    KeyOut=KeyOutCmp[1]
                                if KeyOut!=KeyOutCmp[2]:
                                    ret=0
                                    break                                                           
                            keyCheck=Key1[9]   
                            if  str_hex(keyCheck)==KeyInputCmp[2]:
                                break
                            else:
                                KeyOut=KeyOutCmp[8]
                            if KeyOut!=KeyOutCmp[6]:
                                break                                                            
                        keyCheck=Key1[8]      
                        if  str_hex(keyCheck)==KeyInputCmp[3]:
                            break
                        else:
                            KeyOut=KeyOutCmp[7]
                        if KeyOut!=KeyOutCmp[9]:
                            break                                                        
                    keyCheck=Key1[3]     
                    if  str_hex(keyCheck)==KeyInputCmp[7]:
                        break
                    else:
                        KeyOut=KeyOutCmp[3]  
                    if KeyOut!=KeyOutCmp[1]:
                        ret=0
                        break                                                                                               
                keyCheck=Key1[0]       
                if  str_hex(keyCheck)==KeyInputCmp[8]:
                    break
                else:
                    KeyOut=KeyOutCmp[2]
                if KeyOut!=KeyOutCmp[0]:
                    break                                                                 
            keyCheck=Key1[2]       
            if  str_hex(keyCheck)==KeyInputCmp[1]:
                break
            else:
                KeyOut=KeyOutCmp[5]
            if KeyOut!=KeyOutCmp[7]:
                break                                                 
        keyCheck=Key1[1]      
        if  str_hex(keyCheck)==KeyInputCmp[9]:
            break
        else:
            KeyOut=KeyOutCmp[4]  
        if KeyOut!=KeyOutCmp[5]:
            ret=0
            break            
    keyCheck=Key1[6]       
    if  str_hex(keyCheck)==KeyInputCmp[6]:
        ret=1
        raise KeyError("D0g3") 
        raise KeyError("D0g3")
        raise KeyError("D0g3")
        break
    else:
        KeyOut=KeyOutCmp[0]
    if KeyOut!=KeyOutCmp[3]:
        break         
if ret and KeyOut&(KeyOut|0x100)==0xB397B4AE:
    print("You are a smart boy ! That's right! Yes!")
else:                                    
    raise EOFError("Failed...It doesn't matter")               
Base64Table = "i5jLW7S0GX6uf1cv3ny4q8es2Q+bdkYgKOIT/tAxUrFlVPzhmow9BHCMDpEaJRZN"
#D0g3{It_1s_An_Easy_PYC_R1ght?}
#DataCmp     = "08so+Oagu4Fx6Tls19l4c5bh5TsvSTlW+iuZu8ll"
def My_base64_decode(inputs):
	bin_str = []
	for i in inputs:
		if i != '=':
			x = str(bin((Base64Table.index(i))^0x16)).replace('0b', '')
			bin_str.append('{:0>6}'.format(x))
	#print(bin_str)
	# 输出的字符串
	outputs = ""
	nums = inputs.count('=')
	while bin_str:
		temp_list = bin_str[:4]
		temp_str = "".join(temp_list)
		#print(temp_str)
		# 补足8位字节
		if(len(temp_str) % 8 != 0):
			temp_str = temp_str[0:-1 * nums * 2]
		# 将四个6字节的二进制转换为三个字符
		for i in range(0,int(len(temp_str) / 8)):
			outputs += chr(int(temp_str[i*8:(i+1)*8],2))
		bin_str = bin_str[4:]	
	print("Decrypted String:\n%s "%outputs)

My_base64_decode("08so+Oagu4Fx6Tls19l4c5bh5TsvSTlW+iuZu8ll")
# 74 0A 64 07 83 01 82 01
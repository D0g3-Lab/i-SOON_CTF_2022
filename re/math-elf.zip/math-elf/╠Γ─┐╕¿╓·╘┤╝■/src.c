

//gcc -static -masm=intel q.c -lm -o q
//strip q
//让text可写
//upx -9 q

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/ptrace.h>
#include <dlfcn.h>//Linux动态库的显式调用
#include <unistd.h>
#include <dirent.h>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>

#define BYTE unsigned char
#define DWORD unsigned int
#define WORD unsigned short
char	Euclid(BYTE num1, BYTE num2, char* ret1, char* ret2);
int		mgcd(char n);
void	DivideNUm(BYTE param, BYTE*);
void	find_index(char* base_table, char* src);
int		ErrorFind(DWORD param);

int 	CheckELFStatue();
int  	CheckDbgTool();
int 	AsmCheckDbg();
int 	encrypt_main();
__attribute((constructor)) void MyGdbCheck_BF() //after start
{
	encrypt_main();
	return;
}
int main()
{

	//ÃÜÎÄÐ£Ñé
	BYTE CmpData1[] =
	{
		0x01,0xFF,0xF9,0x02,
		0x05,0xFC,0xFE,0x15,
		0x02,0xF1,0xFA,0x0B,
		0xED,0x05,0x11,0xED,
		0xF7,0x01,0x01,0xFF,
		0x09,0xF3,0x08,0xE9,
		0x0B,0xF6,0x0D,0xEF,
		0x11,0xFC,0x01,0xFC,
		0x01,0xFF,0xF9,0x02,
		0x05,0xFC,0xFE,0x15,
		0x02,0xF1,0xFA,0x0B,
		0xED,0x05,0x11,0xED,
		0xF7,0x01,0x01,0xFF,
		0x09,0xF3,0x08,0xE9,
		0x0B,0xF6,0x0D,0xEF,
	};
	//ÃÜÎÄÐ£Ñé
	BYTE CmpData2[] =
	{
		0x04,0x08,0x24,0x12,
		0x0A,0x0C,0x2A,0x18,
		0x18,0x2E,0x3C,0x0C,
		0x14,0x04,0x04,0x14,
		0x2A,0x24,0x1C,0x24,
		0x28,0x14,0x10,0x3A,
		0x02,0x14,0x1C,0x18,
		0x1C,0x1C,0x10,0x08,
		0x04,0x08,0x24,0x12,
		0x0A,0x0C,0x2A,0x18,
		0x18,0x2E,0x3C,0x0C,
		0x14,0x04,0x04,0x14,
		0x2A,0x24,0x1C,0x24,
		0x28,0x14,0x10,0x3A,
		0x02,0x14,0x1C,0x18,
		0x1C,0x1C,0x10,0x08,
	};
	//Ã÷ÎÄÐ£Ñé

	BYTE flag_step[] =
	{
		0x01,0x03,0x02,0x01,
		0x01,0x02,0x02,0x02,
		0x02,0x01,0x01,0x03,
		0x02,0x01,0x01,0x03,
		0x02,0x01,0x01,0x01,
		0x02,0x03,0x05,0x01,
		0x02,0x02,0x01,0x02,
		0x02,0x01,0x05,0x02,
		0x01,0x03,0x02,0x01,
		0x01,0x02,0x02,0x02,
		0x02,0x01,0x01,0x03,
		0x02,0x01,0x01,0x03,
		0x02,0x01,0x01,0x01,
		0x02,0x03,0x05,0x01,
		0x02,0x02,0x01,0x02,
		0x02,0x01,0x05,0x02,
	};
	//char flag[] = "D0g3{There_Is_A_Long_Way_To_Go_}";
	//char flag[] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
	char flag[128];
	BYTE CmpData3[] = "0AF2F20AF31C1C04F202F708F508F5082032F2F208F3040A0AF2F204F7082A122AF504F2F204F2F2F2F20D34F20DF50A12F302F21212F2F2F2F20DF30A";
	char WinGame[] = "You Are Always The Best";
	char LoseGame[] = "Nver Give Up A Dream,Although It was hard";
	char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwzyz0123456789{}";
	BYTE CmpDataBak[256];
	int i = 0;
	unsigned int tmp1 = 0;
	unsigned int tmp2 = 0;
	unsigned int GetOut = 0;
	int len = 0;
	
	long long lrip = (long long)main;

	memset(flag,0,128);
	printf("--------------------- Weclome  AnXunCTF ----------------------\n");
	printf("--------------------- Input Flag A Try -----------------------\n");
	printf("***** The important thing is not only taking the flag*********\n");
	printf("************** but alsoto learn what you want ****************\n");
	printf("Input:...\n");
	scanf("%s",flag);
	len = strlen(flag);
	CheckELFStatue();
	GetOut = 0x7f0c759e;
	
	while (1)
	{
		while (1)
		{
			if (GetOut == 0x3ae0371)
			{
				GetOut = 0x43722996;
				break;
			}
			while (1)
			{
				if (GetOut == 0x159573fd)
					break;
				while (1)
				{
					if (GetOut == 0x0d0150c4)
						break;
					while (1)
					{
						if (GetOut == 0x7df42d47)
							break;
						else
						{
							if (log(len) + 3.14159265358979 > 6.62345678910123)//32 33 ¶¼²»»áËÀÇÌÇÌ
							{
								puts(LoseGame);
								sleep(1);
								GetOut = 0x05a47c03;//³¤¶ÈÐ£ÑéÊ§°Ü
								break;
							}
							else if (GetOut == 0x7f0c759e)
							{
								GetOut = 0x08ff48d2;//³¤¶ÈÐ£Ñé³É¹¦
								break;
							}
						}
						GetOut = 0x7df42d47;//n´Î½øÈë
					}
					if (ErrorFind(GetOut))
					{
						break;
					}
					find_index(table, flag);
					for (i = 0; i < len; i++)
						flag[i] = (flag[i] * 37 + 47) - (flag[i] * 37 + 47) / 64 * 64;
					//»ùÓÚAxN+BxM=(A,B)µÄ¼ìÑé
					memset(CmpDataBak, 0, 256);
					for (i = 0; i < len / 2; i++)
					{
						tmp1 = Euclid(flag[2 * i + 0], flag[2 * i + 1], &CmpDataBak[2 * i + 0], &CmpDataBak[2 * i + 1]);
					}
					if (memcmp(CmpDataBak, CmpData1, len))
					{
						puts(LoseGame);
						sleep(1);
						GetOut = 0x084522e0;//·ÂÉäÃÜÂëÐ£Ñé´íÎó
						break;
					}
					GetOut = 0x0d0150c4;
				}

				if (ErrorFind(GetOut))
				{
					break;
				}
				//»ùÓÚÑ­»·Òì»òµÄ¼ÓÃÜ
				for (i = 0; i < len; i++)
				{
					if (i == len - 1)
					{
						flag[i] = flag[i] ^ flag[0];
					}
					else
					{
						flag[i] = flag[i] ^ flag[i + 1];
					}
				}
				//»ùÓÚÅ·À­º¯ÊýµÄ¼ìÑé
				memset(CmpDataBak, 0, 256);
				for (i = 0; i < len; i++)
				{
					CmpDataBak[i] = mgcd(flag[i]);
				}
				if (memcmp(CmpDataBak, CmpData2, len))
				{
					puts(LoseGame);
					sleep(1);
					GetOut = 0x389c4c34;
					break;
				}
				GetOut = 0x159573fd;
			}
			if (ErrorFind(GetOut))
			{
				break;
			}
			memset(CmpDataBak, 0, 256);
			for (i = 0; i < len; i++)
			{
				tmp1 = strlen(CmpDataBak);
				DivideNUm(flag[i], CmpDataBak + tmp1);
			}

			//»ùÓÚÕªÒªµÄÐ£Ñé
			tmp2 = strlen(CmpDataBak);
			for (i = 0; i < tmp2; i++)
				tmp1 += CmpDataBak[i];
			if (tmp1 != 0x00001B72)
			{
				puts(LoseGame);
				sleep(1);
				GetOut = 0x3c227587;
				break;
			}
			GetOut = 0x3ae0371;
		}

		if (GetOut == 0x43722996)
		{
			tmp1 = 0;
			for (i = 0; i < len; i++)
			{
				
				if (memcmp(CmpDataBak + tmp1, CmpData3 + tmp1, flag_step[i] * 2))
				{
					puts(LoseGame);
					sleep(1);
					return -1;
				}
				tmp1 += flag_step[i] * 2;
			}
			puts(WinGame);
			break;
		}
		switch (GetOut)
		{
		case 0x05a47c03:
			puts(LoseGame);
			sleep(1);
			break;
		case 0x084522e0:
			puts(LoseGame);
			sleep(1);
			break;
		case 0x389c4c34:
			puts(LoseGame);
			sleep(1);
			break;
		case 0x3c227587:
			puts(LoseGame);
			sleep(1);
			break;
		default://0x7df42d47 n´Î½øÈë
			puts(LoseGame);
			sleep(1);
			GetOut = 0x7df42d47;
			
			break;
		}
	}
	return 0;
}
void find_index(char* base_table, char* src)
{
	int i = 0, ii = 0;
	int len_table = 0;
	int len_src = 0;

	len_table = strlen(base_table);
	len_src = strlen(src);
	for (i = 0; i < len_src; i++)
		for (ii = 0; ii < len_table; ii++)
			if (src[i] == base_table[ii])
				src[i] = ii;
	return;
}
char exgcd(BYTE num1, BYTE num2, int* ret1, int* ret2)
{
	//通过引用传回x与y的值
	char d = 0;
	char z = 0;
	CheckDbgTool();
	if (!num2)
	{
		//最后一步 num2 == 0
		*ret1 = 1;
		*ret2 = 0;
		return num1;
	}
	d = exgcd(num2, num1 % num2, ret1, ret2);
	z = *ret1;
	*ret1 = *ret2;
	*ret2 = z - (num1 / num2) * (*ret2);
	return d;
}
char Euclid(BYTE num1, BYTE num2, char* ret1, char* ret2)
{
	//通过引用传回x与y的值
	char d = 0;
	char z = 0;
	CheckDbgTool();
	if (!num2)
	{
		//最后一步 num2 == 0
		*ret1 = 1;
		*ret2 = 0;
		return num1;
	}
	d = Euclid(num2, num1 % num2, ret1, ret2);
	z = *ret1;
	*ret1 = *ret2;
	*ret2 = z - (num1 / num2) * (*ret2);
	return d;
}
int mgcd(char n)
{
	int i = 0;
	char res = n, t = n;
	CheckDbgTool();
	for (i = 2; i * i <= t; i++)
	{
		if (n - n / i * i == 0)
		{
			while (n - n / i * i == 0)
				n /= i;
			res = res / i * (i - 1);
		};
	}
	if (n > 1)
		res = res / n * (n - 1);
	return res;
}
void DivideNUm(BYTE param, BYTE* out)
{
	int i = 2;//2ÊÇ×îÐ¡µÄËØÊý
	char tmp[8];
	CheckDbgTool();
	while (param > i)
	{
		if (param - param / i * i == 0)
		{
			memset(tmp, 0, 8);
			sprintf(tmp, "%02X", i ^ 0xf0);
			strcat(out, tmp);
			param /= i;
		}
		else
		{
			i++;
		}
	}
	memset(tmp, 0, 8);
	sprintf(tmp, "%02X", param ^ 0x0f);
	strcat(out, tmp);
	//printf("0x%02X,", strlen(out) / 2);
	return;
}
int ErrorFind(DWORD param)
{
	DWORD ErrorCOde[] =
	{
		0x05a47c03,
		0x084522e0,
		0x389c4c34,
		0x3c227587,
		0x7df42d47
	};
	int i = 0;
	for (i = 0; i < 5; i++)
	{
		if (param == ErrorCOde[i])
			return 1;
	}
	return 0;
}
int CheckELFStatue()
{
	void* handle;//定义句柄指针变量
	long (*lp_ptrace)(enum __ptrace_request request, pid_t pid);//定义函数指针变量
	char sz_func[] = { 0x60,0x64,0x62,0x71,0x73,0x75,0x10 };
	char sz_libname[] = {
		0x3F,0x7C,0x79,0x72,
		0x3F,0x68,0x28,0x26,
		0x4F,0x26,0x24,0x3D,
		0x7C,0x79,0x7E,0x65,
		0x68,0x3D,0x77,0x7E,
		0x65,0x3F,0x7C,0x79,
		0x72,0x73,0x3E,0x63,
		0x7F,0x3E,0x26,0x10
	};
	//获取包含'ptrace'的库的句柄
	int i = 0;
	char* lp = 0;
	lp = sz_func;
	for (i = 0;; i++)
	{
		lp[i] = lp[i] ^ 0x10;
		if (lp[i] == 0)
			break;
	}
	lp = sz_libname;
	for (i = 0;; i++)
	{
		lp[i] = lp[i] ^ 0x10;
		if (lp[i] == 0)
			break;
	}

	handle = dlopen(sz_libname, RTLD_LAZY);

	//对动态解析函数ptrace的引用,go变量存的是ptrace的地址
	lp_ptrace = dlsym(handle, sz_func);
	if (lp_ptrace(PTRACE_TRACEME, 0) == -1)
	{
		asm(
			".intel_syntax noprefix;"
			"xor eax, eax;"
			"mov al, 0x1;"
			"xor ebx, ebx;"
			"int 0x80 ;"
		);
	}
	//关闭句柄
	dlclose(handle);
	return 0;
}
int  CheckDbgTool()
{
	char buf0[32], buf1[128];
	long long qhead = 0;

	FILE* fin;
	qhead = (long long)CheckDbgTool;

	//有花指令,然后得有SMC
	snprintf(buf0, 24, "/proc/%d/cmdline", getppid());
	fin = fopen(buf0, "r");
	fgets(buf1, 128, fin);
	fclose(fin);
	if (!strcmp(buf1, "gdb"))
		goto OhNO;
	//puts(buf1);
	else if (!strcmp(buf1, "./linux_server64"))
		goto OhNO;
	//puts(buf1);
	else if (!strcmp(buf1, "./64"))
		goto OhNO;

	return 0;
OhNO:
	asm(
		".intel_syntax noprefix;"
		"xor eax, eax;"
		"mov al, 0x1;"
		"xor ebx, ebx;"
		"int 0x80 ;"
	);
}
int AsmCheckDbg()
{
	//edi  default regparam
	//rbp 	-> rpb
	//rbp-8 -> rip

	int ok = 0;//rbp-12
	long long kp_tmp = (long long)AsmCheckDbg;//[rbp-8]
	//arip;//rbp-24
	asm(".intel_syntax noprefix\n");
	asm(
		"sub rsp,2*8;"
		"push rbx;"
		"push rcx;"
		"push rdx;"
		"push rax;"
		"push rdi;"
		"mov rdi,[rbp-8];"
		"mov ax, 0x80cd;"
		"add rdi,77;"
		"stosw;"
		"mov rbx,0;"
		"mov rcx,0;"
		"mov rdx,0;"
		"mov rax,0x1a;"
		"xor eax,eax;"
		"mov [rbp-12],eax;"

		"pop rdi;"
		"pop rax;"
		"pop rdx;"
		"pop rcx;"
		"pop rbx;"
		"add rsp,2*8;"
	);
	if (ok == -1)
	{
		asm(
			".intel_syntax noprefix;"
			"xor eax, eax;"
			"mov al, 0x1;"
			"xor ebx, ebx;"
			"int 0x80 ;"
		);
	}
	return ok;
}
int encrypt_main()
{
	int myfd;
	int cnt = 0;
	char sztmp[64];
	char* qrip = (char*)main;
	int	len = 2700;
	int i = 0;
	char cmd1[]="lsof -i:23946 > .config";
	char cmd2[]=".config";
	char cmd3[]="rm .config";
	memset(sztmp, 0, 64);

	system(cmd1);
	myfd = open(cmd2, O_RDONLY);
	cnt = read(myfd, sztmp, 64);
	if (cnt != 0)
	{
		for (i = 0; i < len; i++)
			qrip[i] = qrip[i] ^ 0x90;
	}
	close(myfd);
	system(cmd3);
	return 1;
}
